
PRAGMA foreign_keys=ON;
CREATE TABLE microgrid(microgrid_id TEXT PRIMARY KEY,name TEXT NOT NULL,description TEXT NOT NULL,timezone TEXT NOT NULL,nominal_frequency_hz REAL NOT NULL CHECK(nominal_frequency_hz>0),nominal_voltage_ll_v REAL NOT NULL CHECK(nominal_voltage_ll_v>0),interval_minutes INTEGER NOT NULL CHECK(interval_minutes>0));
CREATE TABLE bus(bus_id TEXT PRIMARY KEY,microgrid_id TEXT NOT NULL REFERENCES microgrid(microgrid_id),bus_name TEXT NOT NULL,nominal_voltage_ll_v REAL NOT NULL CHECK(nominal_voltage_ll_v>0),phases TEXT NOT NULL CHECK(phases IN ('ABC','AB','A','B','C')));
CREATE TABLE asset(asset_id TEXT PRIMARY KEY,microgrid_id TEXT NOT NULL REFERENCES microgrid(microgrid_id),asset_name TEXT NOT NULL,asset_type TEXT NOT NULL CHECK(asset_type IN ('grid_intertie','solar_pv','battery','load','conductor')),connection_id TEXT NOT NULL,rated_active_power_kw REAL NOT NULL CHECK(rated_active_power_kw>=0),rated_reactive_power_kvar REAL NOT NULL CHECK(rated_reactive_power_kvar>=0));
CREATE TABLE branch(branch_id TEXT PRIMARY KEY,microgrid_id TEXT NOT NULL REFERENCES microgrid(microgrid_id),from_bus_id TEXT NOT NULL REFERENCES bus(bus_id),to_bus_id TEXT NOT NULL REFERENCES bus(bus_id),length_m REAL NOT NULL CHECK(length_m>0),phases TEXT NOT NULL,frequency_hz REAL NOT NULL CHECK(frequency_hz>0),r_ohm_20c_per_phase REAL NOT NULL CHECK(r_ohm_20c_per_phase>0),x_ohm_per_phase REAL NOT NULL CHECK(x_ohm_per_phase>=0),r_ohm_per_m_20c REAL NOT NULL,x_ohm_per_m REAL NOT NULL,inductance_h_per_m REAL NOT NULL,ampacity_a REAL NOT NULL CHECK(ampacity_a>0),model TEXT NOT NULL);
CREATE TABLE conductor(conductor_id TEXT PRIMARY KEY,branch_id TEXT NOT NULL REFERENCES branch(branch_id),phase TEXT NOT NULL CHECK(phase IN ('A','B','C')),material TEXT NOT NULL,length_m REAL NOT NULL CHECK(length_m>0),area_mm2 REAL NOT NULL CHECK(area_mm2>0),rho_ohm_m_at_20c REAL NOT NULL CHECK(rho_ohm_m_at_20c>0),reference_temp_c REAL NOT NULL,temp_coefficient_per_c REAL NOT NULL,gmd_m REAL NOT NULL CHECK(gmd_m>0),gmr_m REAL NOT NULL CHECK(gmr_m>0),ampacity_a REAL NOT NULL CHECK(ampacity_a>0),UNIQUE(branch_id,phase));
CREATE TABLE conductor_sample(conductor_id TEXT NOT NULL REFERENCES conductor(conductor_id),sample_index INTEGER NOT NULL,position_m REAL NOT NULL,area_mm2 REAL NOT NULL CHECK(area_mm2>0),rho_ohm_m_at_20c REAL NOT NULL CHECK(rho_ohm_m_at_20c>0),reference_temp_c REAL NOT NULL,temp_coefficient_per_c REAL NOT NULL,gmd_m REAL NOT NULL,gmr_m REAL NOT NULL,r_ohm_per_m_20c REAL NOT NULL,x_ohm_per_m REAL NOT NULL,ampacity_a REAL NOT NULL,PRIMARY KEY(conductor_id,sample_index),UNIQUE(conductor_id,position_m));
CREATE TABLE measurement_type(measurement_type_id TEXT PRIMARY KEY,display_name TEXT NOT NULL,unit TEXT NOT NULL,semantic_definition TEXT NOT NULL);
CREATE TABLE measurement(measurement_id INTEGER PRIMARY KEY,interval_start TEXT NOT NULL,asset_id TEXT NOT NULL REFERENCES asset(asset_id),measurement_type_id TEXT NOT NULL REFERENCES measurement_type(measurement_type_id),channel TEXT NOT NULL,value REAL,source_version TEXT NOT NULL,UNIQUE(interval_start,asset_id,measurement_type_id,channel),CHECK(value IS NULL OR abs(value)<1e9));
CREATE INDEX idx_measurement_time ON measurement(interval_start);
CREATE INDEX idx_measurement_asset_time ON measurement(asset_id,interval_start);
CREATE TABLE bus_measurement(interval_start TEXT NOT NULL,bus_id TEXT NOT NULL REFERENCES bus(bus_id),voltage_ll_v REAL NOT NULL,voltage_angle_deg REAL NOT NULL,frequency_hz REAL NOT NULL,PRIMARY KEY(interval_start,bus_id));
CREATE TABLE branch_measurement(interval_start TEXT NOT NULL,branch_id TEXT NOT NULL REFERENCES branch(branch_id),current_a REAL NOT NULL,conductor_temperature_c REAL NOT NULL,r_operating_ohm_per_phase REAL NOT NULL,active_loss_kw REAL NOT NULL,reactive_loss_kvar REAL NOT NULL,PRIMARY KEY(interval_start,branch_id));
CREATE TABLE weather(interval_start TEXT PRIMARY KEY,irradiance_w_m2 REAL NOT NULL CHECK(irradiance_w_m2>=0),ambient_temperature_c REAL NOT NULL,cloud_factor REAL NOT NULL CHECK(cloud_factor BETWEEN 0 AND 1));
CREATE TABLE battery_state(interval_start TEXT PRIMARY KEY,asset_id TEXT NOT NULL REFERENCES asset(asset_id),soc_start_pct REAL NOT NULL CHECK(soc_start_pct BETWEEN 0 AND 100),soc_end_pct REAL NOT NULL CHECK(soc_end_pct BETWEEN 0 AND 100),battery_bus_injection_kw REAL NOT NULL,capacity_kwh REAL NOT NULL CHECK(capacity_kwh>0));
CREATE TABLE dispatch(interval_start TEXT PRIMARY KEY,battery_asset_id TEXT NOT NULL REFERENCES asset(asset_id),charge_power_kw REAL NOT NULL CHECK(charge_power_kw>=0),discharge_power_kw REAL NOT NULL CHECK(discharge_power_kw>=0),dispatch_reason TEXT NOT NULL,CHECK(charge_power_kw=0 OR discharge_power_kw=0));
CREATE TABLE interval_summary(interval_start TEXT PRIMARY KEY,pv_generation_kw REAL NOT NULL,total_load_kw REAL NOT NULL,battery_bus_injection_kw REAL NOT NULL,grid_import_kw REAL NOT NULL,grid_reactive_import_kvar REAL NOT NULL,network_active_losses_kw REAL NOT NULL,network_reactive_losses_kvar REAL NOT NULL,remote_bus_voltage_ll_v REAL NOT NULL,frequency_hz REAL NOT NULL);

-- Model-variable metadata: compact ID, unique significance, and directional favorability.

CREATE TABLE variable_assessment (
    variable_id INTEGER PRIMARY KEY,
    significance_score REAL NOT NULL UNIQUE
        CHECK(significance_score >= 0 AND significance_score <= 100),
    favorability CHAR(1) NULL
        CHECK(favorability IS NULL OR favorability IN ('g','b'))
);
CREATE INDEX idx_variable_assessment_score
    ON variable_assessment(significance_score DESC);
